from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string

def notify_author_by_email(post, comment):
    if not post.author.email:
        return False
    subject = f'New comment on your post: {post.title}'
    # You can create an HTML template for emails; here we keep a simple text message
    message = render_to_string('email/new_comment.txt', {
        'post': post,
        'comment': comment,
    })
    send_mail(
        subject,
        message,
        settings.DEFAULT_FROM_EMAIL,
        [post.author.email],
        fail_silently=False,
    )
    return True

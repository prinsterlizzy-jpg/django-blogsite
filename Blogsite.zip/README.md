# Blogsite - Django Blog (ready-to-run)

## Overview
- Project name: **Blogsite**
- App name: **blog**
- Python: 3.10 compatible
- Features: posts, image uploads, comments, email notifications for comments, Bootstrap-styled templates

## Setup (local)
1. Create and activate a Python 3.10 virtual environment.
   ```bash
   python3.10 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

2. Set environment variables for email (example using Gmail SMTP). Create a `.env` file or export in your shell:
   ```bash
   export EMAIL_HOST=smtp.gmail.com
   export EMAIL_PORT=587
   export EMAIL_HOST_USER='your@gmail.com'
   export EMAIL_HOST_PASSWORD='app-password-or-password'
   export EMAIL_USE_TLS=True
   export DEFAULT_FROM_EMAIL='your@gmail.com'
   ```
   **Important**: if using Gmail, set up an App Password or enable "Less secure apps" (not recommended). Use a dedicated SMTP/email provider in production.

3. Run migrations and create superuser:
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   python manage.py createsuperuser
   ```

4. Run the development server:
   ```bash
   python manage.py runserver
   ```
   - Site: http://127.0.0.1:8000/
   - Admin: http://127.0.0.1:8000/admin/

## Notes
- The app uses env vars for email; do NOT store credentials in source for production.
- DEBUG=True in settings for development only. Set DEBUG=False and configure ALLOWED_HOSTS for production.
- For deployment you'll need to configure static/media serving and a production-ready DB.

## Files of interest
- blog/models.py
- blog/views.py
- blog/email_utils.py
- templates/ (Bootstrap-based)
